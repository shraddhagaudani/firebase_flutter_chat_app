import 'package:firebase_flutter_app/models/indexedstack_model.dart';
import 'package:get/get.dart';

class IndexedStackValController extends GetxController{
  IndexedStackValModel indexedStackModel = IndexedStackValModel(indexstackval: 0);
}