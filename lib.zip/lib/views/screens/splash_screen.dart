import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Splash_screen extends StatefulWidget {
  const Splash_screen({super.key});

  @override
  State<Splash_screen> createState() => _Splash_screenState();
}

class _Splash_screenState extends State<Splash_screen> {
  @override
  Widget build(BuildContext context) {
    Future.delayed(
      const Duration(seconds: 5),
      () => Get.offNamed(
        '/login_page',
      ),
    );
    return const Scaffold(
      body: Center(
        child: Text(
          "Splash Screen",
        ),
      ),
    );
  }
}
