class IndexedStackValModel{
  int indexstackval;

  IndexedStackValModel({required this.indexstackval});
}