import 'package:cloud_firestore/cloud_firestore.dart';

mixin DBmixin {
  // addUser({required Map<String, dynamic> data});
  // Stream<QuerySnapshot<Map<String, dynamic>>> fetchAllUsers();
  // Future<void> deleteUser({required String id});

  addUser({required Map<String, dynamic> data});

  Stream<QuerySnapshot<Map<String, dynamic>>> fetchAllUsers();

  Future<void> deleteUser({required String id});
}

class FireBaseFireStoreHelper with DBmixin {
  FireBaseFireStoreHelper._();

  static final FireBaseFireStoreHelper fireBaseFireStoreHelper =
      FireBaseFireStoreHelper._();

  static final FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

  @override
  Future addUser({required Map<String, dynamic> data}) async {
    DocumentSnapshot<Map<String, dynamic>> documentSnapshot =
        await firebaseFirestore.collection("records").doc("users").get();

    Map<String, dynamic>? fetchedData = documentSnapshot.data();

    int Id = (fetchedData == null) ? 0 : fetchedData['id'];
    int Length = (fetchedData == null) ? 0 : fetchedData['length'];

    await firebaseFirestore.collection("users").doc("${++Id}").set(data);

    await firebaseFirestore
        .collection("records")
        .doc("users")
        .update({"id": Id, "length": ++Length});
  }

  @override
  Stream<QuerySnapshot<Map<String, dynamic>>> fetchAllUsers() {
    return firebaseFirestore.collection("users").snapshots();
  }

  @override
  Future<void> deleteUser({required String id}) async {
    await firebaseFirestore.collection("users").doc(id).delete();
  }
}

// class FireBaseFireStoreHelper with DBmixin {
//   FireBaseFireStoreHelper._();
//
//   static final FireBaseFireStoreHelper fireBaseFireStoreHelper =
//       FireBaseFireStoreHelper._();
//
//   static final FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
//
//   @override
//   Future addUser({required Map<String, dynamic> data}) async {
//
//     DocumentSnapshot<Map<String, dynamic>> documentSnapshot =
//         await firebaseFirestore.collection("records").doc("users").get();
//
//     Map<String, dynamic>? fetchedData = documentSnapshot.data();
//
//     int Id = (fetchedData == null) ? 0 : fetchedData['id'];
//     int Length = (fetchedData == null) ? 0 : fetchedData['length'];
//
// // firebaseFirestore.collection("users").add();
//   await  firebaseFirestore.collection("users").doc("${++Id}").set(data);
//
//    await firebaseFirestore
//         .collection("records")
//         .doc("users")
//         .update({"id": Id, "length": ++Length});
//   }
//
//   @override
//   Stream<QuerySnapshot<Map<String, dynamic>>> fetchAllUsers() {
//     return firebaseFirestore.collection("users").snapshots();
//   }
//
//   @override
//   Future<void> deleteUser({required String id}) async{
//    await firebaseFirestore.collection("users").doc(id).delete();
//   }
//
//
//
// }
