import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_flutter_app/utills/helper/fcm_helper.dart';
import 'package:firebase_flutter_app/utills/helper/firebase_auth_helper.dart';
import 'package:firebase_flutter_app/utills/helper/firebasefirestore_helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class Home_page extends StatefulWidget {
  const Home_page({super.key});

  @override
  State<Home_page> createState() => _Home_pageState();
}

class _Home_pageState extends State<Home_page> {
  String? name;
  String? age;

  TextEditingController nameController = TextEditingController();
  TextEditingController ageController = TextEditingController();

  GlobalKey<FormState> adduserformkey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("HomePage"),
        actions: [
          IconButton(
            onPressed: () {
              FirebaseAuthHelper.firebaseAuthHelper.signOut();

              Get.offNamed('/login_page');
            },
            icon: const Icon(CupertinoIcons.power),
          ),
        ],
      ),
      body: StreamBuilder(
        stream: FireBaseFireStoreHelper.fireBaseFireStoreHelper.fetchAllUsers(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Text("ERROR: ${snapshot.error}");
          } else if (snapshot.hasData) {
            QuerySnapshot<Map<String, dynamic>>? data = snapshot.data;
            List allDocs = (data == null) ? [] : data.docs;

            return ListView.builder(
                itemCount: allDocs.length,
                itemBuilder: (context, i) {
                  return ListTile(
                    leading: Text(allDocs[i].id),
                    title: Text(allDocs[i]['name']),
                    subtitle: Text(allDocs[i]['age']),
                    trailing: IconButton(
                      onPressed: () async{
                      await  FireBaseFireStoreHelper.fireBaseFireStoreHelper
                            .deleteUser(id: allDocs[i].id);
                      },
                      icon: const Icon(CupertinoIcons.delete),
                    ),
                  );
                });
          }
          return const Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: insertUser,
        child: const Icon(
          CupertinoIcons.add,
        ),
      ),
    );
  }

  insertUser() {
    Get.dialog(
      AlertDialog(
        title: const Center(
          child: Text("Add User"),
        ),
        content: Form(
          key: adduserformkey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: nameController,
                validator: (val) {
                  return (val!.isEmpty) ? "Please enter name.." : null;
                },
                decoration: const InputDecoration(
                  hintText: "Name",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: ageController,
                validator: (val) {
                  return (val!.isEmpty) ? "Please enter age.." : null;
                },
                decoration: const InputDecoration(
                  hintText: "Age",
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ),
        actions: [
          ElevatedButton(
            onPressed: () async {
              if (adduserformkey.currentState!.validate()) {
                adduserformkey.currentState!.save();

                Get.back();

                String? token = await FCMHelper.fcmHelper.getDeviceToken();

                FireBaseFireStoreHelper.fireBaseFireStoreHelper.addUser(
                  data: {
                    "name": nameController.text,
                    "age": ageController.text,
                    "token": token,
                    "uid": FirebaseAuthHelper.firebaseAuth.currentUser?.uid,
                  },
                );

                Get.showSnackbar(
                  const GetSnackBar(
                    message: "SUCCESSFULLY ADD USER",
                    backgroundColor: Colors.green,
                    duration: Duration(seconds: 3),
                  ),
                );
                nameController.clear();
                ageController.clear();
              }
            },
            child: const Text("ADD USER"),
          ),
          ElevatedButton(
            onPressed: () {
              Get.back();
              nameController.clear();
              ageController.clear();
            },
            child: const Text("CANCEL"),
          ),
        ],
      ),
    );
  }
}
