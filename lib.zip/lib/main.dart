import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_flutter_app/firebase_options.dart';
import 'package:firebase_flutter_app/utills/app_utills.dart';
import 'package:firebase_flutter_app/views/screens/home_page.dart';
import 'package:firebase_flutter_app/views/screens/login_page.dart';
import 'package:firebase_flutter_app/views/screens/otp_loginpage.dart';
import 'package:firebase_flutter_app/views/screens/otpverify_page.dart';
import 'package:firebase_flutter_app/views/screens/splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(
    GetMaterialApp(
      initialRoute: '/splash_screen',
      theme: AppThemes.lighttheme,
      darkTheme: AppThemes.darktheme,
      debugShowCheckedModeBanner: false,
      getPages: [
        GetPage(name: '/', page: () => const Home_page()),
        GetPage(name: '/splash_screen', page: () => const Splash_screen()),
        GetPage(name: '/login_page', page: () => const Login_page()),
        GetPage(name: '/otplogin_page', page: () => const otpLogainpage()),
        GetPage(name: '/otpverify_page', page: () => const Otpverify_page()),
      ],
    ),
  );
}
