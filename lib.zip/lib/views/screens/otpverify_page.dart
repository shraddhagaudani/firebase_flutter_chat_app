import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_flutter_app/views/screens/home_page.dart';
import 'package:firebase_flutter_app/views/screens/otp_loginpage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pinput/pinput.dart';
import '../../utills/helper/firebase_auth_helper.dart';

class Otpverify_page extends StatefulWidget {
  const Otpverify_page({super.key});

  @override
  State<Otpverify_page> createState() => _Otpverify_pageState();
}

class _Otpverify_pageState extends State<Otpverify_page> {
  GlobalKey<FormState> otpverifyformkey = GlobalKey<FormState>();
  String? code;

  @override
  Widget build(BuildContext context) {
    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: const TextStyle(
          fontSize: 20,
          color: Color.fromRGBO(30, 60, 87, 1),
          fontWeight: FontWeight.w600),
      decoration: BoxDecoration(
        border: Border.all(color: const Color.fromRGBO(234, 239, 243, 1)),
        borderRadius: BorderRadius.circular(20),
      ),
    );

    final focusedPinTheme = defaultPinTheme.copyDecorationWith(
      border: Border.all(color: const Color.fromRGBO(114, 178, 238, 1)),
      borderRadius: BorderRadius.circular(8),
    );

    final submittedPinTheme = defaultPinTheme.copyWith(
      decoration: defaultPinTheme.decoration?.copyWith(
        color: const Color.fromRGBO(234, 239, 243, 1),
      ),
    );

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back_ios_rounded,
            color: Colors.white,
          ),
        ),
        elevation: 0,
      ),
      body: Container(
        margin: const EdgeInsets.only(left: 25, right: 25),
        alignment: Alignment.center,
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Image.asset(
              //   'assets/img1.png',
              //   width: 150,
              //   height: 150,
              // ),
              const SizedBox(
                height: 25,
              ),
              Text(
                "Otp Verification",
                style: GoogleFonts.aBeeZee(
                    fontWeight: FontWeight.bold, fontSize: 30),
              ),
              const SizedBox(
                height: 10,
              ),
              const Text(
                "We need to register your phone without getting started!",
                style: TextStyle(
                  fontSize: 16,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(
                height: 30,
              ),
              Pinput(
                length: 6,
                // defaultPinTheme: defaultPinTheme,
                // focusedPinTheme: focusedPinTheme,
                // submittedPinTheme: submittedPinTheme,
                onChanged: (val) {
                  code = val;
                },
                showCursor: true,
                onCompleted: (pin) => print(pin),
              ),
              const SizedBox(
                height: 20,
              ),
              SizedBox(
                width: double.infinity,
                height: 45,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    primary: Colors.blueAccent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  onPressed: () async {
                    try {
                      PhoneAuthCredential credential =
                          PhoneAuthProvider.credential(
                              verificationId: otpLogainpage.verify,
                              smsCode: code!);

                      await FirebaseAuthHelper.firebaseAuth
                          .signInWithCredential(credential);

                      Get.offAllNamed('/');
                    } on FirebaseAuthException catch (e) {
                      e.code;
                    }
                  },
                  child: const Text(
                    "Verify Phone Number",
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              Row(
                children: [
                  TextButton(
                    onPressed: () {
                      Navigator.pushNamedAndRemoveUntil(
                        context,
                        'otplogin_page',
                        (route) => false,
                      );
                    },
                    child: const Text(
                      "Edit Phone Number ?",
                      style: TextStyle(
                        color: Colors.black,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// return Scaffold(
//   body: Form(
//     key: otpverifyformkey,
//     child: Container(
//       padding: const EdgeInsets.all(16),
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Text(
//             "Verify OTP:${widget.phone} ",
//             style: GoogleFonts.aBeeZee(
//                 fontSize: 30, fontWeight: FontWeight.bold),
//           ),
//           const SizedBox(
//             height: 30,
//           ),
//           ElevatedButton(
//             onPressed: () async {
//               // Get.toNamed(
//               //   '/otpverify_page',
//               // );
//
//               if (otpverifyformkey.currentState!.validate()) {
//                 otpverifyformkey.currentState!.save();
//
//                 FirebaseAuthHelper.firebaseAuthHelper.fetchOTP();
//               }
//             },
//             child: const Text("Fetch OTP"),
//           ),
//           const SizedBox(
//             height: 10,
//           ),
//           Pinput(
//             length: 6,
//             androidSmsAutofillMethod:
//                 AndroidSmsAutofillMethod.smsRetrieverApi,
//             focusNode: pinOtpCodeFocus,
//             controller: otpController,
//             defaultPinTheme: PinTheme(
//               width: 56,
//               height: 56,
//               textStyle: const TextStyle(
//                 fontSize: 22,
//                 color: Color.fromRGBO(30, 60, 87, 1),
//               ),
//               decoration: BoxDecoration(
//                 borderRadius: BorderRadius.circular(19),
//                 border: Border.all(
//                   color: const Color.fromRGBO(23, 171, 144, 0.4),
//                 ),
//               ),
//             ),
//             focusedPinTheme: defaultPinTheme.copyWith(
//               decoration: defaultPinTheme.decoration!.copyWith(
//                 borderRadius: BorderRadius.circular(10),
//                 border: Border.all(color: focusedBorderColor),
//               ),
//             ),
//             submittedPinTheme: defaultPinTheme.copyWith(
//               decoration: defaultPinTheme.decoration!.copyWith(
//                 color: fillColor,
//                 borderRadius: BorderRadius.circular(19),
//                 border: Border.all(
//                   color: focusedBorderColor,
//                 ),
//               ),
//             ),
//             errorPinTheme: defaultPinTheme.copyBorderWith(
//               border: Border.all(color: Colors.redAccent),
//             ),
//             pinAnimationType: PinAnimationType.rotation,
//             onChanged: (otp) async {
//               if (otp.length == 6) {
//                 otpController.text = otp;
//                 otpController.selection = TextSelection.fromPosition(
//                   TextPosition(offset: otp.length),
//                 );
//                 FocusScope.of(context).unfocus();
//                 try {
//                   //   FirebaseAuthHelper.firebaseAuthHelper
//                   //       .veRIfy()
//                   //       .then((value) => {if (value.user != null) {
//                   //       Navigator.of(context).push(MaterialPageRoute(
//                   //     builder: (context) =>  Homepage(),
//                   //   ))
//                   // }});
//                   await FirebaseAuth.instance
//                       .signInWithCredential(
//                     PhoneAuthProvider.credential(
//                         verificationId: verificationCode!, smsCode: otp),
//                   )
//                       .then((value) {
//                     if (value.user != null) {
//                       Get.offNamed('/');
//                       // Navigator.of(context).push(MaterialPageRoute(
//                       //   builder: (context) => Homepage(),
//                       // ));
//                     }
//                   });
//                 } catch (e) {
//                   FocusScope.of(context).unfocus();
//                   ScaffoldMessenger.of(context).showSnackBar(
//                     const SnackBar(
//                       content: Text(
//                         "Sign in With phone Number",
//                       ),
//                       duration: Duration(
//                         seconds: 3,
//                       ),
//                     ),
//                   );
//                 }
//               }
//             },
//           ),
//         ],
//       ),
//     ),
//   ),
// );
